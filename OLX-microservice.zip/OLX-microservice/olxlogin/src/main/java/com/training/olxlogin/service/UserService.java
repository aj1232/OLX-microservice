package com.training.olxlogin.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.training.olxlogin.entity.User;
import com.training.olxlogin.web.dto.UserRegistrationDto;

@Service
public interface UserService {

	UserDetails loadUserByUsername(String username) throws UsernameNotFoundException;

	User save(UserRegistrationDto registrationDto);

}
